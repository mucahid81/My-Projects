// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
    apiKey: "AIzaSyBSQKVvT_MKZhw4rW4YkNcKk6ahopMdwzM",
    authDomain: "jobapplication-f3ab7.firebaseapp.com",
    databaseURL: "https://jobapplication-f3ab7-default-rtdb.firebaseio.com",
    projectId: "jobapplication-f3ab7",
    storageBucket: "jobapplication-f3ab7.appspot.com",
    messagingSenderId: "415945914882",
    appId: "1:415945914882:web:238d94eed1e6c325c7051b",
    measurementId: "G-R1L2G73BJ0"
};

firebase.initializeApp(firebaseConfig);

// Firebase veritabanı ve yetkilendirme referansları
const database = firebase.database();
const auth = firebase.auth();

// Yönetici girişi kontrolü
document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    // Giriş yapma işlemleri
    auth.signInWithEmailAndPassword(username, password)
        .then(() => {
            // Giriş başarılı
            document.getElementById('loginPanel').style.display = 'none';
            document.getElementById('adminPanel').style.display = 'block';

            // Yönetici paneli içeriği dinamik olarak oluşturulacak
            setupAdminPanel();
        })
        .catch((error) => {
            alert('Giriş yaparken bir hata oluştu:', error);
        });
});

function refresh()
{
    const menu = document.getElementById('menu');
    menu.innerHTML = "";
    setupAdminPanel();
}

// Yönetici panelini ayarla
function setupAdminPanel() {
    const menu = document.getElementById('menu');
    // Realtime Database'den verileri çek
    database.ref('basvurular').once('value', (snapshot) => {
        snapshot.forEach((childSnapshot) => {
            const basvuruKey = childSnapshot.key;
            const basvuruData = childSnapshot.val();

            // Bootstrap Accordion elemanlarını dinamik olarak oluştur
            const accordionItem = document.createElement('div');
            accordionItem.className = 'accordion-item';

            const accordionHeader = document.createElement('h2');
            accordionHeader.className = 'accordion-header';
            accordionHeader.id = `heading_${basvuruKey}`;

            accordionHeader.innerHTML = `
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse_${basvuruKey}" aria-expanded="false" aria-controls="collapse_${basvuruKey}">
                    <div class="row w-100">
                    <div class="col-md-6">Başvuru - ${basvuruData.adSoyad} </div>
                    <div class="col-md-6">Tarih - ${basvuruData.basvuruTarihi} - ${basvuruData.basvuruSaati}</div>
                    </div>- 
                </button>
            `;

            const accordionCollapse = document.createElement('div');
            accordionCollapse.id = `collapse_${basvuruKey}`;
            accordionCollapse.className = 'accordion-collapse collapse';
            accordionCollapse.setAttribute('aria-labelledby', `heading_${basvuruKey}`);
            accordionCollapse.setAttribute('data-bs-parent', '#menu');

            const accordionBody = document.createElement('div');
            accordionBody.className = 'accordion-body';

            accordionBody.innerHTML = `
                <p>Adı Soyadı: ${basvuruData.adSoyad}</p>
                <p>Telefon No: ${basvuruData.telefonNo}</p>
                <p>E-Posta: ${basvuruData.eposta}</p>
                <p>Açıklama: ${basvuruData.aciklama}</p>
                <button type="button" class="btn btn-primary" onclick="downloadCV('${basvuruKey}')">CV İndir</button>
            `;

            accordionCollapse.appendChild(accordionBody);
            accordionItem.appendChild(accordionHeader);
            accordionItem.appendChild(accordionCollapse);
            menu.appendChild(accordionItem);
        });
    });
}

// CV indirme işlemi
function downloadCV(basvuruKey) {
    // İlgili başvurunun dosya URL'sini al
    database.ref(`basvurular/${basvuruKey}/dosyaUrl`).once('value')
        .then((snapshot) => {
            const dosyaUrl = snapshot.val();
            // Dosyayı yan sekmede görüntüle
            window.open(dosyaUrl, '_blank');
        })
        .catch((error) => {
            console.error('CV indirirken bir hata oluştu:', error);
        });
}