// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
    apiKey: "AIzaSyBSQKVvT_MKZhw4rW4YkNcKk6ahopMdwzM",
    authDomain: "jobapplication-f3ab7.firebaseapp.com",
    databaseURL: "https://jobapplication-f3ab7-default-rtdb.firebaseio.com",
    projectId: "jobapplication-f3ab7",
    storageBucket: "jobapplication-f3ab7.appspot.com",
    messagingSenderId: "415945914882",
    appId: "1:415945914882:web:238d94eed1e6c325c7051b",
    measurementId: "G-R1L2G73BJ0"
  };

firebase.initializeApp(firebaseConfig);

// Firebase veritabanı ve depolama referansları
const database = firebase.database();
const storage = firebase.storage();

// Form gönderme olayını dinleme
document.getElementById('basvuruForm').addEventListener('submit', function(event) {
    event.preventDefault();

    // Kullanıcıdan alınan bilgiler
    const adSoyad = document.getElementById('adSoyad').value;
    const telefonNo = document.getElementById('telefonNo').value;
    const eposta = document.getElementById('eposta').value;
    const aciklama = document.getElementById('aciklama').value;
    const dosya = document.getElementById('dosya').files[0];

    // Dosya yükleme işlemleri
    const storageRef = storage.ref(`basvuru_dosyalari/${dosya.name}`);
    storageRef.put(dosya).then((snapshot) => {
        console.log('Dosya başarıyla yüklendi.');
        // Dosyanın yüklendiği URL'i al
        return snapshot.ref.getDownloadURL();
    }).then((dosyaUrl) => {
        // Başvuru tarihini ve saatinin alınması
        const tarih = new Date().toLocaleDateString();
        const saat = new Date().toLocaleTimeString();
        // Realtime Database'e veri ekleme
        database.ref('basvurular').push({
            adSoyad: adSoyad,
            telefonNo: telefonNo,
            eposta: eposta,
            aciklama: aciklama,
            dosyaUrl: dosyaUrl,
            basvuruTarihi: tarih,
            basvuruSaati: saat
        });

        // Formu temizleme
        document.getElementById('basvuruForm').reset();
        console.log('Başvuru başarıyla gönderildi.');
    }).catch((error) => {
        alert('Dosya yüklenirken bir hata oluştu:', error);
    });
});