let bars = document.querySelector(".bars");
let navigation = document.querySelector(".navigation");

function NavActivete(){
    if(bars.classList.contains("barsactive")){
        bars.classList.remove("barsactive");
        navigation.classList.remove("nav-active");
    }
    else{
        bars.classList.add("barsactive");
        navigation.classList.add("nav-active");
    }
}